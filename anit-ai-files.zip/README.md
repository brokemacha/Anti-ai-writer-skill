# 🧠 Anti-AI Writer — Claude Skill

A custom Claude skill that makes AI-generated text sound authentically human. Based on research into how AI detectors work and what patterns they look for.

---

## What It Does

This skill teaches Claude to write (and rewrite) text so it:
- Passes AI detection tools like Originality.ai
- Sounds natural, varied, and human
- Has real rhythm, opinion, and personality — not just polished slop

It targets the three core signals AI detectors measure:

| Signal | What It Means | Fix |
|--------|--------------|-----|
| **Perplexity** | How predictable your word choices are | Use unexpected, specific language |
| **Burstiness** | Variation in sentence length & structure | Mix short and long sentences |
| **Syntactic Repetition** | Same rhythms and patterns repeated | Break patterns deliberately |

---

## Installation

### Claude.ai (No-code)

1. Download `SKILL.md` from this repo
2. Create a folder called `anti-ai-writer` and place `SKILL.md` inside it
3. ZIP the folder
4. Go to **claude.ai → your initials (bottom left) → Customize → Skills → "+"**
5. Upload the ZIP file
6. Make sure **Code Execution** is enabled under **Settings → Capabilities**

### Claude Code (Developers)

```bash
mkdir -p ~/.claude/skills/anti-ai-writer
curl -o ~/.claude/skills/anti-ai-writer/SKILL.md \
  https://raw.githubusercontent.com/YOUR_USERNAME/anti-ai-writer-skill/main/SKILL.md
```

### Quick Option — Project Instructions

Paste the contents of `SKILL.md` directly into a Claude Project's instructions field. No ZIP needed.

---

## How to Use It

Once installed, just ask Claude naturally:

> *"Rewrite this to sound more human"*
> *"Write a paragraph about X — make it sound natural, not AI"*
> *"Humanize this text"*

Claude will automatically apply the skill.

---

## What It Fixes

### ❌ Banned patterns
- **Rule of threes** — AI always lists exactly 3 examples. This skill breaks that.
- **Uniform sentence length** — wall-to-wall long sentences read like a machine gun
- **Banned vocabulary** — delve, robust, innovative, enhanced, groundbreaking, comprehensive...
- **No hedging** — AI states everything as fact. Humans say "it appears," "arguably," "I think"
- **Em dashes (—)** — AI loves them. This skill avoids them.
- **Staying perfectly on-topic** — real writers go on slight tangents
- **Overly polished tone** — no opinion, no personality, no mess

### ✅ What gets added
- Mixed sentence rhythm (short punchy ones + longer flowing ones)
- Personal voice and opinion
- Hedging and uncertainty where appropriate
- Specific details instead of vague claims
- Natural transitions instead of formulaic connectors
- Slight tangents and asides that signal a real thinking person

---

## Before & After

**Before (AI-generated):**
> Organic photovoltaic devices have emerged as a promising class of solar energy technologies due to their lightweight nature, mechanical flexibility, and compatibility with solution-based low-temperature fabrication processes. Despite this progress, challenges in long-term operational stability, scalability, and morphological control remain.

**After (humanized):**
> Organic photovoltaic devices have attracted attention for years — largely because of their potential to offer something traditional silicon can't: cheap, printable solar films you could theoretically roll out like newsprint. The efficiency numbers still lag behind, honestly, but the fabrication costs are what keeps people interested.

---

## The AI Bingo Checklist

Run this on any text before submitting it:

- [ ] All sentences roughly the same length?
- [ ] Rule of three used multiple times?
- [ ] No hedging — everything stated as fact?
- [ ] No personal voice or opinion?
- [ ] Cliché sentence starters (In conclusion / Therefore / It is important)?
- [ ] Generic AI vocabulary: delve, robust, innovative, enhanced?
- [ ] Em dashes (—) used heavily?
- [ ] No tangents at all?

**If most boxes are checked → rewrite it.**

---

## Credits

Skill logic based on the YouTube video:
**"I Can Spot AI Writing Instantly – Bypass ChatGPT Detectors for FREE"**

Additional patterns sourced from [Wikipedia: Signs of AI Writing](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing)

---

## License

MIT — free to use, modify, and share.

---

## Topics

`claude` `claude-skill` `ai-writing` `humanizer` `ai-detection` `bypass-ai-detection` `writing` `anthropic`
