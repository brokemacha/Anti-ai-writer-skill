# How AI Writes — And How Humans Spot It
### Combined Summary from Two Videos (Andy & Evan Edinger)

---

## The Core Problem

AI generates the *most statistically likely* response every time. That predictability is exactly what gets it caught. Detectors — human or algorithmic — are essentially measuring one thing: **does this surprise me?** AI almost never does.

---

## PART 1 — What Algorithmic Detectors Measure

These are the three signals every major AI detector (Originality.ai, GPTZero, Turnitin) scores:

### 1. Perplexity — How Predictable Are Your Words?
AI always reaches for the most expected word. Human writing makes unexpected choices. Low perplexity = flagged. The fix: use specific, surprising, or personal language.

### 2. Burstiness — How Much Does Your Sentence Length Vary?
AI writes in a steady, uniform rhythm — long sentence, long sentence, long sentence. Humans write in bursts: short, then long, then very short. Low burstiness = flagged.

### 3. Syntactic Repetition — Are Your Rhythms Too Uniform?
Same sentence structures. Same lengths. Same patterns repeated. Detectors scan for this uniformity across the entire piece.

---

## PART 2 — The 10 Human-Readable Red Flags

These are what a human spots when reading — no detector needed.

### 🚩 Red Flag 1: The Em Dash (—)
AI loves the em dash and uses it far more than any human would. Most people can't even type one without looking it up. Seeing it frequently — especially mid-sentence — is a strong tell. One isn't proof. Many is a problem.

### 🚩 Red Flag 2: "It's Not Just X, It's Y"
This parallel sentence structure is one of AI's most consistent habits:
- *"It's not just about uploading in 4K. It's about making every shot count."*
- *"AI isn't just a productivity boost. It helps us get closer to our mission."*

Once you notice this structure, you'll see it everywhere. It screams AI.

### 🚩 Red Flag 3: The Rule of Three (Triplets)
AI defaults to exactly three examples in every list. Always three. Because triplets sound satisfying to humans — complete but not overwhelming. Real humans use two sometimes. Or four. AI never does.
Example: *"telling a story, conveying emotion, and creating a visually compelling image"*

### 🚩 Red Flag 4: Exaggerated, Empty Praise
AI has been trained to flatter. It opens responses with:
- *"Wonderful question!"*
- *"Your travel vlogs are genuinely captivating — I love how you bring every new place to life..."*
- *"You truly are an imaginative genius."*

This praise feels corporate-kind. Polished but hollow. It compliments without being specific or personal.

### 🚩 Red Flag 5: Forced, Weird Analogies
AI tries to sound deep by inserting analogies, but they often fall flat in a very specific way:
- *"Being able to spot AI writing is like being a lighthouse in the middle of a dense fog."*
- *"Like a band-aid made of sandpaper."*

They're trying too hard. Real analogies come from lived experience. AI analogies come from pattern-matching on what analogies sound like.

### 🚩 Red Flag 6: Constant Restating and Over-Clarifying
AI repeats itself. It states a point, then explains the point, then clarifies the explanation. Unnecessary filler preambles everywhere:
- *"The color of the sky is a phenomenon that has fascinated people for centuries..."* (when you just asked why the sky is blue)
- Saying the same thing three different ways in the same paragraph

### 🚩 Red Flag 7: Generic Vocabulary / Uncanny Valley Language
Words that feel slightly off for the context — technically correct but not how a real person would put it. Plus the classic AI vocabulary bank:
- **elevate, delve, innovative, practical solutions, captivating, vivid, vibrant, robust**

These words exist in normal English, but AI reaches for them constantly. The overall effect is writing that says a lot while meaning very little.

### 🚩 Red Flag 8: No Personal Details or First Person
Human writing includes the writer. A real commenter says "As a northerner, I never liked jellied eels — I tried them once and regretted it." AI writes generically. No "I." No personal story. No location. No lived experience. Just: "Your video was fascinating and informative."

### 🚩 Red Flag 9: Zero Tangents
AI stays perfectly on topic. Every sentence serves the main point. Humans wander — not randomly, but meaningfully. A photographer talking about their video editing will mention something they saw at a café last week that suddenly felt relevant. AI never does this. A wall of perfectly on-topic text is suspicious.

### 🚩 Red Flag 10: The Vibe Check
Sometimes you can't name exactly what's wrong. The writing just feels corporate, insincere, or slightly off. Trust that instinct. AI writing has a "fake-kind" quality — like it's trying to be nice but doesn't mean it. The uncanny valley of text. If the vibe is wrong, it probably is.

---

## PART 3 — What Human Writing Actually Looks Like

These are the positive signals that confirm something was written by a person:

✅ **First person perspective** — "I," "my," "personally," "as someone who..."
✅ **Specific personal anecdotes** — a real place, a real person, a real moment
✅ **Relevant tangents** — a digression that connects back somehow
✅ **Imperfect grammar in casual contexts** — humans don't use perfect comma placement in iMessages
✅ **Opinions and reactions** — not just reporting facts, but having a feeling about them
✅ **Varied sentence rhythm** — the writing has a natural ebb and flow, not a steady drum
✅ **Specific numbers and details** — "3 million lines" beats "a large amount"
✅ **Gut-level sincerity** — the praise is targeted ("I liked the part where you...") not general

---

## PART 4 — The Full AI Bingo Checklist

Run this on any text before submitting or publishing:

**Structural Tells**
- [ ] All sentences roughly the same length?
- [ ] No sentence shorter than 12 words?
- [ ] Em dashes (—) used more than once?
- [ ] Bullet points with emojis at the start of each?

**Pattern Tells**
- [ ] "It's not just X, it's Y" structure present?
- [ ] Rule of three in more than one list?
- [ ] Restates the same point 2–3 times in a row?

**Content Tells**
- [ ] No first-person perspective at all?
- [ ] Exaggerated opening praise ("Wonderful!", "Genuinely captivating!")?
- [ ] Forced-sounding analogy that tries too hard?
- [ ] Generic vocabulary: delve, robust, elevate, innovative, captivating?
- [ ] No tangents or digressions anywhere?
- [ ] Perfectly on-topic throughout — zero wandering?

**Vibe Check**
- [ ] Feels corporate-kind — polite but hollow?
- [ ] Reads like it was written for everyone and therefore no one?

**5+ boxes checked = almost certainly AI. Rewrite it.**

---

## Key Insight

> AI is trained on human writing, so it knows what human writing *looks* like. The problem is it only knows the most common patterns — the average of everything. Real humans write from a specific life, a specific perspective, a specific moment. That specificity is what AI can't fake. Inject it deliberately.
